const CREDIT = "credit_card";
const DEBIT = "debit_card";
const QR = "qr";
const VOUCHER_CARD = "voucher_card";
const LINK = "link";
const POINT = "point";

function getAvailablePaymentMethods() {
	console.log("before getPaymentMethods");
	getPaymentMethods(callbackResult);
};

function callbackResult(result, error) {

	var menu_payment_method = document.getElementById("menu_payment_method");

	var textMap = new Map([
		[CREDIT	, "Credit card"],
		[DEBIT	, "Debit card" ],
		[VOUCHER_CARD , "Voucher"],
		[QR		, "QR"],
		[LINK	, "Link"],
		[POINT	, "Point"]
	]);

	var iconsMap = new Map([
		[CREDIT	, "far fa-credit-card"],
		[DEBIT	, "far fa-credit-card" ],
		[VOUCHER_CARD, "far fa-credit-card" ],
		[QR		, "fas fa-qrcode"],
		[LINK	, "fas fa-link"],
		[POINT	, "far fa-credit-card"]
	]);

	for (var item in result) {

		var methodId = result[item];
		console.log("option: " + methodId);

		var button = document.createElement("a");
		button.href = "#";
		button.id = methodId;
		button.setAttribute("class", "btn btn-primary btn-lg d-block mt-2");
		button.setAttribute("onclick", "openPaymentMethod(document.getElementById('amount').value, document.getElementById('description').value, '" + methodId + "')")
		button.innerHTML = "<i class='" + iconsMap.get(methodId) + "'></i> " + textMap.get(methodId);

		menu_payment_method.appendChild(button)
    }

    document.getElementById("spinner_payment_method").style.display = "none";
}

function openPaymentMethod(amount, description, method) {
	console.log("before launchPaymentMethod: " + method + " amount: " + amount + " description: "+ description);
    window.localStorage.setItem('magicML', amount);
    var config = new PaymentConfigBuilder();
    config.setAmount(parseFloat(amount));
    config.setPaymentMethod(method)
    config.setDescription(description)
    launchPaymentCallback(config, paymentResultCallback)
}

function openPaymentFlow(amount, description) {
    window.localStorage.setItem('magicML', amount);
    var config = new PaymentConfigBuilder();
    config.setAmount(parseFloat(amount));
    config.setDescription(description)
    config.setMetadata(encodeURIComponent({"attr": "123"}));
    config.setCallbackSuccess('response/congrats.html');
    config.setCallbackError('response/error.html');
    launchPayment(config, resultError);
}

function openPaymentFlowWithFunctions(amount, description) {
    window.localStorage.setItem('magicML', amount);
    var config = new PaymentConfigBuilder();
    config.setAmount(parseFloat(amount));
    config.setDescription(description)
    config.setMetadata(encodeURIComponent({"attr": "123"}));
    config.setCallbackSuccess('callback_payment_success');
    launchPayment(config, resultError);
}

function openPaymentFlowNotCallbacks(amount, description) {
    window.localStorage.setItem('magicML', amount);
    var config = new PaymentConfigBuilder();
    config.setAmount(parseFloat(amount));
    config.setDescription(description)
    launchPayment(config, resultError)
}

function resultError(result, error) {
    if(error) {
        callbackErrorPayment(error.data)
    }
}

function callbackErrorPayment(result) {
    document.getElementById("callback-result").innerHTML = `<h4 class="bg-danger text-white p-3 m-0 d-block">
    ${result}<i class="far fa-window-close ml-5" onclick='closeResult()'></i></h4>`;
}

function closeResult() {
    document.getElementById("callback-result").innerHTML = "";
}

function paymentCheckExternalReferenceStatus(externalReference) {
    window.localStorage.setItem('magicML', externalReference);
    launchPaymentCheckExternalReferenceStatus(externalReference, paymentResultCallback);
}

function openPaymentFlowSimpleCallback(amount, description, printOnTerminal) {
    console.log("before openPaymentFlowSimpleCallback: " + " amount: " + amount + " description: "+ description + " printOnTerminal: "+ printOnTerminal);
    window.localStorage.setItem('magicML', amount);
    var config = new PaymentConfigBuilder();
    config.setAmount(parseFloat(amount));
    config.setDescription(description);
    config.setPrintOnTerminal(printOnTerminal);

    launchPaymentCallback(config, paymentResultCallback)
}

function paymentResultCallback(result, error) {
    if (error) {
        document.getElementById("callback-result").innerHTML = "<h2 class=\"bg-danger text-white p-3 m-0 d-block\">Callback Error Result <i class=\"far fa-window-close\" onclick='closeResult()'></i></h2><div class='p-2'>" + JSON.stringify(error) + "</div>";
    } else {
        document.getElementById("callback-result").innerHTML = "<h2 class=\"bg-success text-white p-3 m-0 d-block\">Callback Success Result <i class=\"far fa-window-close\" onclick='closeResult()'></i></h2><div class='p-2'>" + JSON.stringify(result) + "</div>";
    }
}
